package com.example.backend.model;

import lombok.Data;

@Data
public class Tag {
    private int tagId;
    private String tagName;

}
